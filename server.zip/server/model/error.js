module.exports.ok = function (data) {
    var err = {};
    err.errcode = 10000;
    err.msg = "提交正确";
    if (data)
        err.data = data;
    return new Promise(function (resolve, reject) {
        resolve(err);
    });
}

module.exports.error = function (code, msg) {
    var err = {};
    err.errcode = code;
    err.msg = msg;
    return new Promise(function (resolve, reject) {
        resolve(err);
    });
}