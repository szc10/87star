var mysql = require('../mysql/index')('87STAR');
var table = "inf_list";

module.exports.select = function (index) {
    /**
     * 挑选一条支付记录
     */
    var promise = new Promise(function (resolve, reject) {
        var pdata = {};
        pdata.table = table;  //设计传入的表
        pdata.index = index;
        mysql.select(pdata).then(function (data) {
            resolve(data);
        }).catch(function(data){
            reject(data);
        });
    });
    return promise;
}
