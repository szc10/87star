var error = require('../model/error');
var member = require("../model/member");
var coin = require("../model/coin");

module.exports.select_p = function(body){
    var id  = body.id;
    return coin.select({
         p_user:id
    }).then(function(data){
        return error.ok(data);
    }).catch(function(){
         return error.error(-1,"系统错误");
    });
}

module.exports.select_a = function(body){
    var id  = body.id;
    return coin.select({
         a_user:id
    }).then(function(data){
        return error.ok(data);
    }).catch(function(){
         return error.error(-1,"系统错误");
    });
}