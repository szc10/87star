var error = require('../model/error');
// var member = require("../model/member");
var inf = require("../model/inf");
module.exports.test = function () {
    return new Promise(function (resolve, reject) {
        resolve("123");
    });
}

module.exports.select = function(body){
    var id  = body.id;
    return inf.select({
         user_id:id
    }).then(function(data){
        return error.ok(data);
    }).catch(function(){
         return error.error(-1,"系统错误");
    });
}