var error = require('../model/error');
var member = require("../model/member");
module.exports.test = function () {
    return new Promise(function (resolve, reject) {
        resolve("123");
    });
}

module.exports.login = function (body) {
    var username = body.username;
    var password = body.password;
    return member.select({ username: username }).then(function (data) {
        if(data.length<1){
            return error.error(-10001,"用户不存在");
        }
        if(data[0].password!=password){
             return error.error(-10002,"用户名密码不一致");
        }
        return error.ok(data[0]);
    }).catch(function () {
        return error.error(-1,"系统错误");
    });
}

module.exports.select_one = function (body) {
var id  = body.id;
    return member.select({ id: id }).then(function (data) {
        if(data.length<1){
            return error.error(-10001,"用户不存在");
        }
        return error.ok(data[0]);
    }).catch(function () {
        return error.error(-1,"系统错误");
    });
}

module.exports.select_custom = function(body){
    var id  = body.id;
    return member.select_custom(id).then(function(data){
        return error.ok(data);
    }).catch(function(){
         return error.error(-1,"系统错误");
    });
}