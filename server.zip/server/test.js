
try{ 
 var o = 123;
 console.log(o.l.l);
}catch(e){ 
 console.log("异常捕获");
}finally{
    
}
console.log(123); 

